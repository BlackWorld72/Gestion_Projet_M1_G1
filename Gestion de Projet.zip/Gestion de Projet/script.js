qs = document.getElementById("qs")
b = document.body
diff = 0

function updateQuestion() {
    i = 1
    while (true) {
        d = document.getElementById("qs" + i)
        i += 1
        if (!d) {
            return
        }
        d.remove()
    }
}

function questionTexte(difficulty) {
    diff = difficulty
    updateQuestion()
    for (var i = 1 ; i < 6 ; i++) {
        let div = document.createElement('div')
        let newH2 = document.createElement('h2')
        let inp = document.createElement('input')
    
        switch (difficulty) {
            case 0:
                newH2.textContent = i + ") " + data.easy[0].questions[0].question
                break
            case 1:
                newH2.textContent = i + ") " + data.normal[0].questions[0].question
                break
            case 2:
                newH2.textContent = i + ") " + data.hard[0].questions[0].question
                break
            default:
        }
    
        inp.setAttribute("type", "select");
        inp.setAttribute("id", "inp" + i);
        inp.setAttribute("class", "inpanswer");
    
        newH2.setAttribute("id", i);
        newH2.setAttribute("class", "question");
    
        div.setAttribute("id", "qs" + i);
        div.setAttribute("class", "divquestion");
    
        qs.append(div)
        div.append(newH2)
        div.append(inp)
    }
}

function questionMath(difficulty) {
    diff = difficulty
    updateQuestion()
    for (var i = 1 ; i < 6 ; i++) {
        let div = document.createElement('div')
        let newH2 = document.createElement('h2')
        let inp = document.createElement('input')
    
        switch (difficulty) {
            case 0:
                newH2.textContent = i + ") " + data.easy[0].questions[i-1].question
                break
            case 1:
                newH2.textContent = i + ") " + data.normal[0].questions[i-1].question
                break
            case 2:
                newH2.textContent = i + ") " + data.hard[0].questions[i-1].question
                break
            default:
        }
    
        inp.setAttribute("type", "text");
        inp.setAttribute("id", "inp" + i);
        inp.setAttribute("class", "inpanswer");
    
        newH2.setAttribute("id", i);
        newH2.setAttribute("class", "question");
    
        div.setAttribute("id", "qs" + i);
        div.setAttribute("class", "divquestion");
    
        qs.append(div)
        div.append(newH2)
        div.append(inp)
    }
}


function answerMath() {
    update()
    for (var i = 1 ; i < 6 ; i++) {
        div = document.getElementById("qs" + i)
        let newH2 = document.createElement('h4')
        switch (diff ) {
            case 0:
                newH2.textContent = i + ") " + data.easy[0].questions[i-1].answer
                break
            case 1:
                newH2.textContent = i + ") " + data.normal[0].questions[i-1].answer
                break
            case 2:
                newH2.textContent = i + ") " + data.hard[0].questions[i-1].answer
                break
            default:
        }
        newH2.setAttribute("id", "ans" + i);
        newH2.setAttribute("class", "answer");
        div.append(newH2)
    }
}   

function update() {
    i = 1
    while (true) {
        d = document.getElementById("ans" + i)
        i += 1
        if (!d) {
            return
        }
        d.remove()
    }
}